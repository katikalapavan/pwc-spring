import {BrowserRouter,NavLink,Route, Switch} from "react-router-dom"
import Login1 from "./Login"
import Register1 from "./Register"
import Portfolo1 from "./Portfolo"
import UserDetails from "./UserDetails"
import NotFound from "./404"
function Landingpage(props){
    return(
        <div>
             <hr/>
            Landingpage
            <hr/>
            {routes}
        </div>
    )
}
export default Landingpage

const Header=()=>{
    return(
        <header>
            <NavLink to="/" exact={true}></NavLink>
            <br/>
            <NavLink to="/Register" >Register</NavLink>
            <br/>
            <NavLink to="/Portfolo">Portfolo</NavLink>
            <NavLink to="/UserDetails">UserDetails</NavLink>
        </header>
    )
}
const routes=(

    <BrowserRouter>
    <Header/>
    <Switch>
    <Route path='/' component={Login1} exact={true}/>                   
    <Route path='/Register' component={Register1}/>
    <Route path='/Portfolo' component={Portfolo1}/>
    <Route path='/UserDetails/:id' component={UserDetails}/>
    <Route component={NotFound}/>
    </Switch>
    </BrowserRouter>
)