//import {Component} from "react";

function UserDetails(props){
    return(
        <div>
            <h3>UserDetails id:{props.match.parms.id}</h3>
        </div>
    )
}
export default UserDetails