//import {Component} from "react";
import {NavLink} from "react-router-dom"
function Register(props){
    return(
        <div>
            
            <form >
        <div class="form-group">
          <label for="email">Email address:</label>
          <input type="email" class="form-control" id="email"/>
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" class="form-control" id="pwd"/>
        </div>
        <div class="form-group">
          <label for="name">Password:</label>
          <input type="name" class="form-control" id="name"/>
        </div>
        
        <button type="submit" class="btn btn-default">Submit</button>
        <p>bac to login <NavLink to="/">Login</NavLink></p>
      </form> 
        </div>
    )
}
export default Register