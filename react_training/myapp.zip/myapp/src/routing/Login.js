//import {Component} from "react";
import {NavLink} from "react-router-dom"
function Login(props){
    return(
        <div><h3>raj</h3>
        <form >
        <div class="form-group">
          <label for="email">Email address:</label>
          <input type="email" class="form-control" id="email"/>
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" class="form-control" id="pwd"/>
        </div>
        
        <button type="submit" class="btn btn-default">Submit</button>
        <p>not signed click here to<NavLink to="/Register" >Register</NavLink></p>
      </form> 
      </div>
     
    )
}
export default Login