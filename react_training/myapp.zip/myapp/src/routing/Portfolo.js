//import {Component} from "react";

function Portfolo(props){
    return(
        <div>
            <h3>Portfolo</h3>
        </div>
    )
}
export default Portfolo