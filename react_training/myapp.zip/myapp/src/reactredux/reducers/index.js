import AuthReducer from "./authReducer";

const { combineReducers } = require("redux");
const { default: counterReducer } = require("./counterReducer");




const appreducer= combineReducers({
    cntr : counterReducer,
    auth:AuthReducer
})
export default appreducer