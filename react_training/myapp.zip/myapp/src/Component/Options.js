import {Component} from "react";
import Option from "./Option";
export default class Options extends Component{
    render(){
        return(
           <div>
               <div>
                   {
                       this.props.udata.map((data)=><Option mydata={data} deldata={this.props.du}/>)
                   }

                
                 <button onClick={this.props.eu}>Deleteusers</button>
                
                </div>
                <div>
                  {
                      this.props.udept.map((data) => (<Option mydept={data}/>)
                      )
                  }
                   <button onClick={this.props.e}>Deletedept</button>
                </div>
            
                </div>

                
        )
    }
}