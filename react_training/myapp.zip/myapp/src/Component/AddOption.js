import {Component} from "react";
//export default class AddOption extends Component{
    function AddOption(props){
    
     const addUser=(e)=>{
        e.preventDefault()
       // alert('user is added')
       
        const data =e.target.elements.uname.value
        props.addUsr(data)
        const data1 =e.target.elements.email.value
        const data2 =e.target.elements.city.value
       // alert(data)

       
       document.getElementById('show').innerHTML=data
       document.getElementById('show1').innerHTML=data1
       document.getElementById('show2').innerHTML=data2
      
    }
    
    //render(){
        return(
          
                 <div>
                <form onSubmit={addUser}>
                name:<input type="text" name="uname"/>
                <br/>
                <br/>
                email:<input type="email" name="email"/>
                <br/>
                <br/>
                city:<input type="city" name="city"/>
                <br/>
                <br/>
                <button>Call me</button>
                <br/>
                </form>
                <table border="2">
                    <tr>
                    <th>name</th>
                    <th>email</th>
                    <th>city</th>
                    </tr>
                   
                    <tr>
               <td> <div id='show'></div></td>
               <td>   <div id='show1'></div></td>
               <td>   <div id='show2'></div></td>

                
                </tr>
                </table>
                </div>
               
                
        )
    }
//}
export default AddOption