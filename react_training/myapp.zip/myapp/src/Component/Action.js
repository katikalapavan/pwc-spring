import {Component} from "react";

export default class Action extends Component{
    render(){
        return(
           <div>
                <h3>hello</h3>
             <button disabled={!this.props.isData}>showAction</button>
             <button disabled={!this.props.iData}>showAction2</button>
                </div>
                
        )
    }
}