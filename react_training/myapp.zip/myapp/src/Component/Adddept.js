import {Component} from "react";
export default class Adddept extends Component{
    
    
        adddept=(e)=>{
        e.preventDefault()
       // alert('user is added')
       
        const data =e.target.elements.udep.value
        this.props.adddep(data)
       
       // alert(data)

       
    
    }
    
    render(){
        return(
          
                 <div>
                <form onSubmit={this.adddept}>
               
                dep:<input type="text" name="udep"/>
                <button>Call</button>
                <br/>
                </form>
               
                   
              
                </div>
               
                
        )
    }
}