import {Component} from "react";


export default class Option extends Component{
    deleteUser=()=>{
        this.props.deldata(this.props.mydata)
    }
    render(){
        return(
           <div>
               <div>
              {this.props.mydata} 
                  <br/>
                <button onClick={this.deleteUser}> Delete</button> 
                </div>

<div>
{this.props.mydept} 
    
  </div>
  </div>

        )
    }

}
