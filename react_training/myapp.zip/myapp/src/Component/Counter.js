import {Component} from "react";
export default class Counter extends Component{
    state={
        count:10
    }
add =()=>
{
    this.setState((prevState)=>{
        return{
count:prevState.count+1
        }
    })
}   
sub =()=>
{
    this.setState((prevState)=>{
        return{
count:prevState.count-1
        }
    })
} 
reset =()=>
{
    this.setState((prevState)=>{
        return{
            count:prevState.count-1
    
    }
    })
} 
    render(){
        return(
           <div>
<p> current count is {this.state.count}</p>
              <button onClick={this.add} >inc</button>
              <button onClick={this.sub}>dece</button>
              <button onClick={this.reset}>reset</button>
                </div>
            
        )
    }
}