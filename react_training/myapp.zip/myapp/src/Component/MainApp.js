import {Component} from "react";
import Action from "./Action";
import Adddept from "./Adddept";
import AddOption from "./AddOption";
import Counter from "./Counter";
import Footer from "./Footer";
import Header from "./Header";
import Options from "./Options";

export default class MainApp extends Component{
  state={
      userdata:[],
      dept:[] 

  }
  emptyUserArray=()=>{
      this.setState(()=>{
          return{
              userdata:[]
          }
      })
  }
  emptyUserDept=()=>{
    this.setState(()=>{
        return{
            dept:[]
        }
    })
}

addUser=(data)=>{
    this.setState((prevState)=>{
        return{
            userdata:prevState.userdata.concat(data)
        }
    })
}
adddept=(data)=>{
    this.setState((prevState)=>{
        return{
            dept:prevState.dept.concat(data)
        }
    })
}

deleteUser=(data)=>{
    this.setState((prevState)=>{
        return{
        userdata:prevState.userdata.filter((input)=>data!==input)
        }
    })
}


    render(){
        //const userdata =['admin','manager','QA']
      //  const dept=['IT','CSE']
        return(
           <div>
                <h3>
                    welcome to main app</h3>
                    <Options udata={this.state.userdata} udept= {this.state.dept} 
                    eu={this.emptyUserArray} e={this.emptyUserDept} du={this.deleteUser}/>
                  
                    <Header hmessage="welcome header1"/>
                   
                    <Action isData={this.state.userdata.length>0} iData={this.state.dept.length>0}/>
                   
                    <AddOption addUsr={this.addUser}/>
                  <Counter hmessage="Welcome counter"/>
                  <Adddept adddep={this.adddept}/>
                  <hr/>
                  <Footer hmessage="welcome footer"/>
                 
                </div>
        )
    }
}