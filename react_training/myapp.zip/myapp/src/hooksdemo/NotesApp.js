const {useState,useEffect}=require("react")
function NotesApp(){


    const[notes,setNotes]=useState([])
    const [title,setTitle]=useState('')
    const [title1,setemail]=useState('')

    useEffect(()=>{
        const notesdata=JSON.parse(localStorage.getItem('notes'))
        setNotes(notesdata)
    },[])
   
    useEffect(()=>{
//console.log('called during load and update the states');
localStorage.setItem('notes',JSON.stringify(notes))

    })
    
const addNote=(e)=>{
        e.preventDefault()
        setNotes([
            ...notes,{title},{title1}
        ])
            setTitle('')
            setemail('')

    }
   
   const removeNote=(title)=>{
       setNotes(notes.filter((note)=>note.title !== title))
   }
    return(
        <div>
            <h3> Notes Lists...</h3>
           {notes.map((note)=>(
               <div>
               <h3>{note.title} {note.title1}</h3>
              <button onClick={()=>removeNote(note.title)}>delete</button>
               </div>

              ))}
            <p>Add notes</p>
            <form onSubmit={addNote}>
                Title:<input type='text' value={title} onChange={(e)=>setTitle(e.target.value)}/>
                <br/>
                email:<input type='text' value={title1} onChange={(e)=>setemail(e.target.value)}/>
                <br/>
                <button>Add</button>

            </form>
        </div>
    )
}
export default NotesApp