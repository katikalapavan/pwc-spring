const {useState}=require("react");
function HooksDemo(props){
    const [count,setCount]=useState(10)

 
    const reset=()=>{
    count[count]=setCount(10)
    //    reset();
    }

    return(
        <div>
            <p>
                the current state is {count}
            </p>
            <button onClick={()=>setCount(count+1)}>INC</button>
            <button onClick={()=>setCount(count-1)}>DEC</button>
            <button onClick={reset}>Reset</button>
        </div>
    )
}

HooksDemo.defaultProps=
{
    count:0
}


export default HooksDemo