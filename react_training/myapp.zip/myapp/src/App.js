//const {default:MainApp}=require("./Component/MainApp");
//import MainApp from "./Component/MainApp";
//import RestApp from "./mycomp/RestApp";
//import App1 from "./hooksdemo/App1";
//import NotesApp from "./hooksdemo/NotesApp";
//import Task1 from "./Component/Task/Task1";
//import Contextdemo from "./ContextApp/Contextdemo";
//import Landingpage from "./routing/Landingpage";
//import Register from "./routing/Register";
//import UserDetails from "./routing/UserDetails";
//import Portfolo from "./routing/Portfolo";
//import Login from "./routing/Login";
//import task from "./task/task1";

//import Header from "./Component/Header";
//import Footer from "./Component/Footer";
import { useDispatch, useSelector } from "react-redux"
import{increment, login, logout} from "./reactredux/reducers/actions/useraction"
import{decrement} from "./reactredux/reducers/actions/useraction"

import{reset} from "./reactredux/reducers/actions/useraction"


function App() {

  const counter= useSelector((state)=> state.cntr)
  const auth= useSelector((state)=> state.auth)
const dispatch =useDispatch()
  return(
    <div>
      
  <p>The current count is {counter}</p>
  <button onClick={()=>dispatch(increment())}>inc</button>
  <button onClick={()=>dispatch(decrement())}>dec</button>
  <button onClick={()=>dispatch(reset())}>res</button>
  <hr/>

  <div>
    <h2>for Auth user only</h2>
    <button onClick={()=>dispatch(login())}>Login</button>
  <button onClick={()=>dispatch(logout())}>Logout</button>

{
  auth ?(
    <div>
      <p>welcome to appplication as you have logged in</p>
    </div>
  ):(
    "Not a valid user"
  )
}



  </div>
    </div>
  )
}
export default App
