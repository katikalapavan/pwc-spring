import{useState,createContext,useContext} from "react"
const empContext=createContext()
//const salContext=createContext()
function Contextdemo(){
const[employee]=useState({id:101,name:'admin',location:'banglore',Salary:12345})

    return(
        
        <div>
            <empContext.Provider value={employee} >
                
            <Employee/>
            </empContext.Provider>
            </div>



    )
}

function Employee(){
    let context=useContext(empContext)
    return(
        <div>welcome to employee
             <br/>
            name:{context.name}
            <br/>
            location:{context.location}
<Salary/>

        </div>
    )
}

function Salary(){
    let context=useContext(empContext)
    return(
        <div>welcome to salary
            <br/>
       name:{context.name}
            <br/>
            salary:{context.Salary}
            </div>
    )
}


export default Contextdemo