const express=require('express')
const cors=require('cors')
const app=express();
app.get('/api/customer',cors(),(req,res)=>{
    const customers=[
        {id:101,firstName:'john',email:'john@gmail.com'},
        {id:102,firstName:'hello',email:'hello@gmail.com'},
        {id:103,firstName:'jarugu',email:'jarugu@gmail.com'},
    ]
    res.json(customers)
})
app.listen(5000,()=>{
    console.log('server is ready');
})